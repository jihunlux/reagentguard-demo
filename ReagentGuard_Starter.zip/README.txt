ReagentGuard 시연용 웹사이트 시작 안내
======================================

포함 파일
- index.html : 웹사이트 전체 파일입니다. HTML/CSS/JavaScript가 한 파일에 들어 있습니다.

태블릿에서 실행하는 가장 쉬운 방법
1. 이 ZIP 파일을 태블릿에 다운로드하고 압축을 풉니다.
2. index.html 파일을 누릅니다. 파일 앱에서 열리지 않으면 Chrome의 파일 열기 기능을 이용하거나, 아래 온라인 배포 방법을 사용하세요.
3. 대시보드에서 시약 등록, 시약 관리, 센서 모듈 추가, 측정 기록, CSV 내보내기를 시험할 수 있습니다.

인터넷에서 실제 주소를 가진 사이트로 공개하는 방법 (GitHub Pages)
1. Chrome에서 https://github.com 에 접속하고 계정을 만들거나 로그인합니다.
2. 새 저장소(repository)를 만듭니다. 이름 예: reagentguard-demo. 공개(Public)로 설정하고 생성합니다.
3. 저장소 화면에서 Add file → Upload files를 선택합니다.
4. 압축을 푼 폴더 안의 index.html을 업로드하고 Commit changes를 누릅니다.
5. 저장소 Settings → Pages로 이동합니다.
6. Build and deployment에서 Deploy from a branch를 선택하고 Branch는 main, 폴더는 /(root)로 설정한 뒤 Save를 누릅니다.
7. 잠시 기다리면 Pages 화면에 https://사용자이름.github.io/reagentguard-demo/ 형태의 사이트 주소가 표시됩니다.

태블릿 팁
- Chrome에서 데스크톱 사이트 옵션을 켜면 GitHub 메뉴를 찾기 쉬울 수 있습니다.
- 업로드할 때 ZIP 파일 자체가 아니라 압축을 푼 index.html 파일을 업로드합니다.
- GitHub 화면의 버튼 이름은 업데이트에 따라 조금 달라질 수 있습니다.

현재 버전의 한계
- 시약 정보와 센서 목록은 브라우저의 localStorage에 저장됩니다. 같은 브라우저에서만 유지되며 다른 기기와 자동 동기화되지 않습니다.
- 측정값은 가상 예시입니다. 실제 센서와 연결되어 있지 않습니다.
- 센서 추천은 시연용 규칙이며 화학적 호환성을 보증하지 않습니다.
- 실제 서비스로 발전시키려면 사용자 계정, 서버 데이터베이스, 보안, 센서 데이터 연동이 추가로 필요합니다.
